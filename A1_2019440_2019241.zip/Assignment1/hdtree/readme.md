# HDTree - Python implementation of a Decision Tree 

## Installation
A directory containing this repository has to be put into your Python search path. Alternatively you can directly add the directory to your *site-packages* folder of your python interpreter.
## Documentation
Please take a look at the complementary notebook inside the *examples* folder. You can view it inside your browser also directly here: [https://nbviewer.jupyter.org/urls/bitbucket.org/gang_of_nerds/hdtree/raw/6d7d171a89600b909905b16d3ef6b819318566e8/examples/HDTree%20Tutorial%20Basics.ipynb](https://nbviewer.jupyter.org/urls/bitbucket.org/gang_of_nerds/hdtree/raw/6d7d171a89600b909905b16d3ef6b819318566e8/examples/HDTree%20Tutorial%20Basics.ipynb)